# One Piece IPTV — Android project

## Open the correct project
Open **this folder** (`one_piece_iptv_starter`) in Android Studio. It is the only Android/Gradle project in this package; the duplicate nested Android project has been removed to avoid opening the wrong copy.

## Requirements
- Android Studio with Android SDK Platform 35
- JDK 17 (Android Studio's bundled JDK 17 is suitable)
- Internet access on the first Gradle sync so Gradle can download plugins and dependencies

## Build a test APK
1. Open this folder in Android Studio.
2. Allow Gradle Sync to finish. If prompted, install Android SDK 35.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. The debug APK should be created at `app/build/outputs/apk/debug/app-debug.apk`.

## Current scope
This is a UI prototype. The login form is demonstrational only; it does not authenticate against a server or save credentials. Live playback, playlist parsing, catalog integration, subscription management, and production authentication are not yet implemented. Media3 dependencies are included for the next authorized-stream playback step.

Use only playlists and streams you own or are authorized to access. Do not embed provider credentials in the app.
