package com.onepiece.iptv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF090B10)
private val Panel = Color(0xFF171B24)
private val Gold = Color(0xFFFFC247)
private val Red = Color(0xFFE44747)
private val Muted = Color(0xFFB7BBC5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OnePieceApp() }
    }
}

@Composable
fun OnePieceApp() {
    var showLogin by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf("Home") }
    val tabs = listOf("Home", "Live TV", "Movies", "Series", "Favorites", "Settings")
    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Gold)) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            if (showLogin) {
                LoginScreen(onContinue = { showLogin = false })
            } else {
                Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()) {
                        Column {
                            Text("ONE PIECE", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
                            Text("IPTV  •  PREMIUM PLAYER", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                        }
                        Text("FR  |  العربية  |  EN", color = Muted, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(22.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        items(tabs) { tab ->
                            Surface(color = if (selected == tab) Gold else Panel,
                                shape = RoundedCornerShape(20.dp), modifier = Modifier.clickable { selected = tab }) {
                                Text(tab, color = if (selected == tab) Ink else Color.White,
                                    fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    when (selected) {
                        "Home" -> HomeContent(onSelect = { selected = it })
                        "Live TV" -> SectionContent("Live TV", "Your authorized live channels will appear here.")
                        "Movies" -> SectionContent("Movies", "Browse your licensed movie catalog.")
                        "Series" -> SectionContent("Series", "Browse your licensed series catalog.")
                        "Favorites" -> SectionContent("Favorites", "Your saved channels and titles.")
                        else -> SectionContent("Settings", "Language • Player • Account")
                    }
                }
            }
        }
    }
}

@Composable
private fun LoginScreen(onContinue: () -> Unit) {
    var mode by remember { mutableStateOf("Xtream Codes") }
    var server by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var playlist by remember { mutableStateOf("") }
    var language by remember { mutableStateOf("Français") }
    var message by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("☠", color = Gold, fontSize = 42.sp)
        Text("ONE PIECE", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        Text("IPTV  •  PREMIUM PLAYER", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(26.dp))
        Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Text("Welcome aboard", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Connect using your authorized playlist", color = Muted, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("Xtream Codes", "M3U URL").forEach { item ->
                        Surface(
                            color = if (mode == item) Gold else Ink,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).clickable { mode = item; message = "" }
                        ) {
                            Text(item, color = if (mode == item) Ink else Color.White,
                                fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 12.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                }
                if (mode == "Xtream Codes") {
                    StyledField(server, { server = it }, "Server URL", keyboard = KeyboardType.Uri)
                    StyledField(username, { username = it }, "Username")
                    StyledField(password, { password = it }, "Password", secret = true)
                } else {
                    StyledField(playlist, { playlist = it }, "M3U playlist URL", keyboard = KeyboardType.Uri)
                }
                Text("Language", color = Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Français", "العربية", "English").forEach { item ->
                        Surface(color = if (language == item) Red else Ink, shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.clickable { language = item }) {
                            Text(item, color = Color.White, fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 11.dp, vertical = 9.dp))
                        }
                    }
                }
                Button(
                    onClick = {
                        val valid = if (mode == "Xtream Codes") server.isNotBlank() && username.isNotBlank() && password.isNotBlank()
                                    else playlist.isNotBlank()
                        if (valid) {
                            message = "Demo sign-in only — API authentication will be connected in a later step."
                        } else {
                            message = "Please complete the required fields."
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Red),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("CONNECT", color = Color.White, fontWeight = FontWeight.Black, letterSpacing = 1.sp) }
                if (message.isNotBlank()) Text(message, color = Gold, fontSize = 12.sp)
                Text("Use only playlists and streams you are authorized to access.", color = Color.Gray, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Preview without account", color = Gold, modifier = Modifier.clickable { onContinue() })
    }
}

@Composable
private fun StyledField(value: String, onValueChange: (String) -> Unit, label: String,
                        keyboard: KeyboardType = KeyboardType.Text, secret: Boolean = false) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Gold,
            unfocusedBorderColor = Color(0xFF3A3F4B),
            focusedLabelColor = Gold,
            unfocusedLabelColor = Muted,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            cursorColor = Gold
        )
    )
}

@Composable
private fun HomeContent(onSelect: (String) -> Unit) {
    Column {
        Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(24.dp)) {
                Text("YOUR ENTERTAINMENT, YOUR WAY", color = Gold, fontSize = 12.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                Text("Welcome aboard!", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Live TV, movies and series in one place.", color = Muted, fontSize = 15.sp)
                Spacer(Modifier.height(18.dp))
                Button(onClick = { onSelect("Live TV") }, colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                    Text("Explore Live TV", color = Color.White)
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Text("EXPLORE", color = Gold, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            CategoryTile("LIVE TV", "Channels", Modifier.weight(1f)) { onSelect("Live TV") }
            CategoryTile("MOVIES", "Cinema", Modifier.weight(1f)) { onSelect("Movies") }
            CategoryTile("SERIES", "Episodes", Modifier.weight(1f)) { onSelect("Series") }
        }
    }
}

@Composable
private fun CategoryTile(title: String, subtitle: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = modifier.clickable(onClick = onClick)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = Gold, fontWeight = FontWeight.Black, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SectionContent(title: String, message: String) {
    Column(Modifier.fillMaxWidth().padding(top = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Gold, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(message, color = Muted)
        Spacer(Modifier.height(20.dp))
        Text("Demo screen • API integration comes next", color = Color.Gray, fontSize = 12.sp)
    }
}
