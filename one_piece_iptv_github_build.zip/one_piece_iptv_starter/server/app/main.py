from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Literal

app = FastAPI(title="One Piece IPTV API", version="0.1.0",
              description="API starter for authorized IPTV/VOD content.")

class Channel(BaseModel):
    id: str
    name: str
    category: str
    stream_url: str = Field(description="Authorized stream URL; keep private in production.")
    language: Literal["fr", "ar", "en"] = "fr"

class CatalogItem(BaseModel):
    id: str
    title: str
    kind: Literal["movie", "series"]
    poster_url: str | None = None
    description: str = ""

# Demo catalog only. Replace with a database and licensed content records.
CHANNELS: list[Channel] = []
CATALOG: list[CatalogItem] = []

@app.get("/health")
def health():
    return {"status": "ok", "service": "one-piece-iptv-api"}

@app.get("/v1/channels", response_model=list[Channel])
def list_channels(category: str | None = None):
    if category:
        return [c for c in CHANNELS if c.category.lower() == category.lower()]
    return CHANNELS

@app.get("/v1/catalog", response_model=list[CatalogItem])
def list_catalog(kind: Literal["movie", "series"] | None = None):
    if kind:
        return [item for item in CATALOG if item.kind == kind]
    return CATALOG

@app.get("/v1/catalog/{item_id}", response_model=CatalogItem)
def catalog_detail(item_id: str):
    for item in CATALOG:
        if item.id == item_id:
            return item
    raise HTTPException(status_code=404, detail="Catalog item not found")

@app.get("/")
def root():
    return {"message": "One Piece IPTV API starter", "docs": "/docs"}
