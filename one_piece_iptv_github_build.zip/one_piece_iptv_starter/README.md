# One Piece IPTV — Android starter

A Kotlin + Jetpack Compose prototype for an IPTV player using only playlists and streams the user is authorized to access.

## Project structure
- `app/` — the single Android application project
- `server/` — FastAPI API starter with health and demo catalog endpoints
- `docker-compose.yml` — optional local API/database setup
- `ANDROID_BUILD.md` — Android Studio build instructions

## Android
Open the repository root (this folder) in Android Studio. Requirements and APK build steps are in `ANDROID_BUILD.md`.

## Backend (optional)
Use Python 3.11+, then run:

```bash
cd server
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

API docs: http://127.0.0.1:8000/docs

## Important
This is a starter prototype, not a compiled APK or production service. The login screen is demo-only. Production requires secure authentication, password hashing, rate limiting, audit logging, HTTPS, rights verification, and appropriate content protection. Do not embed credentials or stream URLs in the Android app.

## Build an APK from a phone (GitHub Actions)

1. Create a GitHub account or sign in, then create a **public or private** repository.
2. Upload the contents of this project ZIP to the repository's root (not the ZIP file itself).
3. Open the repository's **Actions** tab and select **Build Android APK**.
4. Tap **Run workflow**. Wait for the run to finish successfully.
5. Open the completed run, scroll to **Artifacts**, and download `one-piece-iptv-debug-apk`.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

The workflow builds a debug APK. It does not sign a release APK for Play Store distribution.
